package com.example.peliculas.models

enum class Estado {
        PENDIENTE, VISTA, FAVORITA
}