//Genero.kt
package com.example.peliculas.models

enum class Genero {
    ACCION, COMEDIA, DRAMA, DOCUMENTAL, ROMANCE, FANTASIA, CIENCIA_FICCION, AVENTURA, TERROR, OTRO
}